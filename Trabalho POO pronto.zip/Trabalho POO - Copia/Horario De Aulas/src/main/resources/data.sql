insert into professor(nome,sobrenome) values ('Albert','Einstein');
insert into professor(nome,sobrenome) values ('Nikolas','Tesla');
insert into professor(nome,sobrenome) values ('Isaac','Newton');
insert into professor(nome,sobrenome) values ('J.R.R.','Tolkien');
insert into professor(nome,sobrenome) values ('C.S.','Lewis');